#!/bin/bash

#==============================================================================
# Script: backup_full.sh
# Description: Realiza un backup comprimido de un directorio de origen
#              a un directorio de destino, con validaciones y opción de ayuda.
# Author: Fausto Villalba
# Date: 2025-07-22
#==============================================================================

# --- Función para mostrar la ayuda del script ---
mostrar_ayuda() {
    echo "Uso: $0 [ORIGEN] [DESTINO]"
    echo "Realiza un backup comprimido de un directorio de ORIGEN a un DESTINO."
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
}

#==============================================================================
# Bloque Principal
#==============================================================================

# --- Validación de la opción de ayuda ---
if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
    exit 0
fi

# --- Validación del número de argumentos ---
if [ "$#" -ne 2 ]; then #
    echo "Error: Número incorrecto de argumentos."
    mostrar_ayuda
    exit 1
fi

# --- Asignación de variables ---
ORIGEN=$1
DESTINO=$2

# --- Validación de directorios de origen y destino ---
if [ ! -d "$ORIGEN" ]; then #
    echo "Error: El directorio de origen '$ORIGEN' no existe o no es un directorio."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

# --- Creación del nombre del archivo de backup ---
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
NOMBRE_BKP="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
RUTA_COMPLETA_BKP="$DESTINO/$NOMBRE_BKP"

# --- Ejecución del backup ---
echo "Iniciando backup de '$ORIGEN' a '$RUTA_COMPLETA_BKP'..."

tar -czvf "$RUTA_COMPLETA_BKP" "$ORIGEN"

# --- Verificación del resultado del comando tar ---
if [ "$?" -eq 0 ]; then #
    echo "Backup finalizado con éxito."
    exit 0
else
    echo "Error: El backup falló."
    exit 1
fi
